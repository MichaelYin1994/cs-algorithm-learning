modAL.uncertainty
=================

.. automodule:: modAL.uncertainty
   :members:
