modAL.density
=============

.. automodule:: modAL.density
   :members:
