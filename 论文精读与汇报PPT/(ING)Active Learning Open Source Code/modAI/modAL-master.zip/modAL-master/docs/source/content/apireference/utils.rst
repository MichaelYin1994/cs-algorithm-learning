modAL.utils
===========

.. automodule:: modAL.utils
   :members:
