modAL.expected_error
====================

.. automodule:: modAL.expected_error
   :members:
