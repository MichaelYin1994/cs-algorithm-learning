modAL.batch
===========

.. automodule:: modAL.batch
   :members:
