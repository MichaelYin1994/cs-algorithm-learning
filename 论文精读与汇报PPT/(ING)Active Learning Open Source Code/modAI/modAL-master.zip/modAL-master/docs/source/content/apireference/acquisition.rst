modAL.acquisition
=================

.. automodule:: modAL.acquisition
   :members:
