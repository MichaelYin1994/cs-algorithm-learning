modAL.disagreement
==================

.. automodule:: modAL.disagreement
   :members:
