modAL.multilabel
=============

.. automodule:: modAL.multilabel
   :members:
