libact.query_strategies.multiclass package
==========================================

Submodules
----------

libact.query_strategies.multiclass.active_learning_with_cost_embedding module
-------------------------------------------------------------------------------

.. automodule:: libact.query_strategies.multiclass.active_learning_with_cost_embedding
    :members:
    :undoc-members:
    :show-inheritance:

libact.query_strategies.uncertainty_sampling module
---------------------------------------------------

.. automodule:: libact.query_strategies.uncertainty_sampling
    :members:
    :undoc-members:
    :show-inheritance:

libact.query_strategies.multiclass.expected_error_reduction module
------------------------------------------------------------------

.. automodule:: libact.query_strategies.multiclass.expected_error_reduction
    :members:
    :undoc-members:
    :show-inheritance:

libact.query_strategies.multiclass.hierarchical_sampling module
-------------------------------------------------------------------------------

.. automodule:: libact.query_strategies.multiclass.hierarchical_sampling
    :members:
    :undoc-members:
    :show-inheritance:

Module contents
---------------

.. automodule:: libact.query_strategies.multiclass
    :members:
    :undoc-members:
    :show-inheritance:
