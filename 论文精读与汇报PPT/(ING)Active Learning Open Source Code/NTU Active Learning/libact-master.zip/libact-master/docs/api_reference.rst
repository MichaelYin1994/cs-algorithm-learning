API Reference
=============

.. toctree::

    libact.base
    libact.labelers
    libact.models
    libact.query_strategies
